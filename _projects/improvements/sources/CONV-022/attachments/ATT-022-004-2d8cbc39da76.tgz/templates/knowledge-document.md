---
status: draft
authority: none
provenance: original
created: YYYY-MM-DD
last_reviewed: YYYY-MM-DD
canonical_sources: []
supersedes: []
superseded_by: []
---

# Title

## Summary

One paragraph: what this document says and why it exists.

## Content

The knowledge itself. Reference canonical sources as `Nortropic/<repo>@<commit>` plus path; do not copy normative text.

## Provenance notes

Where this came from: inspected commits, analyses, conversations.

## Open contradictions & uncertainty

Anything unresolved, contradictory between historical sources, or unverified — labeled, not reconciled.

<!-- Allowed field values (defined in GOVERNANCE.md):
     status:     draft | research | proposed | accepted-informational | superseded | historical
     authority:  none | informational        (no value grants execution authority)
     provenance: original | derived | index | historical-copy
     historical-copy additionally requires: source repository, original path,
     source commit, and source blob identity (git rev-parse <commit>:<path>). -->
