# research/

Original research and analysis produced for Nortropic.

**Does not belong here:** copies of research-shaped documents that are pinned or coupled in a source repository (for example blob-pinned audit documents). Reference those from `references/` instead; copying them requires owner classification per `GOVERNANCE.md`.
