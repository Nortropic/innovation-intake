# reports/

Dated, non-authoritative snapshots: inspections, inventories, status pictures. Documents here carry status `historical` from the day they are written — a report describes a moment, not the present.

**Does not belong here:** anything a process depends on at runtime or verification time, or any document presented as a current source of truth.
