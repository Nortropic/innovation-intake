---
status: historical
authority: none
provenance: original
created: 2026-08-15
last_reviewed: 2026-08-15
canonical_sources:
  - Nortropic/nortropic-system@e56edc08e5f069f16b5bdb853302a0f39c1f7075
  - Nortropic/verkstadsgolvet@330457cfa56646d5f56b7746c0e0064009505eb5
supersedes: []
superseded_by: []
---

# Documentation architecture inventory — 2026-08-15

**STATUS: HISTORICAL INSPECTION SNAPSHOT — AUTHORITY: NONE.** Source repositories were **not** modified by this inspection. All classifications below are **recommendations, not owner decisions**. The category previously labeled SAFE_TO_MOVE is replaced by **SAFE_TO_COPY_PENDING_OWNER_REVIEW**. **No migration has been authorized.**

## 1. Repository state (verified 2026-08-15)

| Repo | Branch | HEAD SHA | origin/main SHA | Working tree |
|---|---|---|---|---|
| nortropic-system | DETACHED | `e56edc08e5f069f16b5bdb853302a0f39c1f7075` | same (HEAD == origin/main) | clean |
| verkstadsgolvet | `main` | `a8285c4190b1ac8b0bea4977451fb820cd21d534` | `330457cfa56646d5f56b7746c0e0064009505eb5` (local 57 behind, 0 ahead) | clean |

Verkstadsgolvet's factory-room docs, handoffs and `docs/reports/**` exist only on origin/main; inspected via `git show origin/main:<path>`.

## 2. Authority map — verkstadsgolvet (origin/main `330457c`)

Three enforced protection tiers: **Tier 1** `PROTECTED_AUTHORITY_PATHS` (`scripts/claude-loop/scope.ts`; owner-author lane only): `CLAUDE.md`, `.claude/**`, `docs/claude-operating-model-v1.md`. **Tier 2** `NEVER_WRITABLE_PATHS` (no lane ever): `docs/nortropic-control-room-plan-v1.md`, `docs/nortropic-control-room-codex-handoff.md` — redundantly enforced by `.claude/settings.json` deny, `.claude/hooks/pre-tool-guard.mjs`, and assertions in `tests/claude-loop/authority-lane.test.ts` + `publication-merge-commit.test.ts`. **Tier 3** frozen by prose convention only: `docs/nortropic-factory-room-master-roadmap-v1.md` + erratum chain (per-task `deniedWrite`, not in scope.ts/hook/settings).

Also load-bearing: `docs/claude-loop-runbook.md` (test-enforced supersession mechanism), `backlog/README.md` + backlog JSONs (reference plan/roadmap/handoff/errata by path), `.claude/agents/*.md`, `scripts/claude-loop/owner-author/system-prompt.md` (marker-checked at runtime by `lanes.ts`), per-slice tests citing frozen docs as `KÄLLA` (`v10-security-hardening.test.ts` reads the plan file at runtime). `content/**` (14 of 15 files) is runtime product data (`readFileSync`, six routes). Verbatim/byte-identity constraints: `requirement-addendum-v3`, `lanes-clarification`, `docs/reports/**` (`HISTORICAL_REPORTS_EDITED=NO` in both errata). Cross-repo chain: nortropic-system backend plan > control-room plan (trust/verdicts/promotion/event contracts) > operating model/roadmap > errata > handoff > backlogs.

## 3. Authority map — nortropic-system (`e56edc0`)

Stated hierarchy (AGENTS.md §Auktoritet = CLAUDE.md = `specs/tasks.spec.json` `authority{}`): `docs/07-konstitution.md` > `docs/03-regelverk.md` > `docs/loop/regler.md` > task in spec > frozen exit_test > plan/drift docs.

Mechanical layers: **§A denied_write** (07, 03, CLAUDE.md + non-doc members) enforced by `controller/policy/cli` (exit 3), `config/managed-settings.json` deny + Seatbelt denyWrite, autopilot `protected_exact`, gate `verify/bin/h-007-exit`. **Authority snapshot**: `controller/verify/cli` copies 07/03/regler.md into every verification workspace — missing ⇒ `Integritetsfel`. **Blob-SHA frozen** (autopilot halts on one changed byte): `harness-substitution-contract-v1.md`, `harness-substitution-audit-2026-08-11.md`, plus `autonomous-loop-plan-v1.md` + `-codex-handoff.md` (only at off-main commit `0b3212c9`). **Literal-string-asserted**: `owner-author-workflow-v1.md`, `remaining-bootstrap-delegation-v1.md` (h-035-exit). **Required on origin/main** for autopilot start: `codex-autopilot-v3-full-roadmap.md`, `owner-h003-attestation-authority-v1.md`, `codex-autopilot-report.schema.json`. **docs_impact (rules 17+22)**: policy gate rejects candidates not touching listed docs in-commit — `docs/05-beslutslogg.md` on all 22 tasks; `docs/loop/drift.md` on 8 (hard-coded in 4 frozen gates); `00-borja-har.md` (h-007); `byggplan-v3.md` (h-016); `AGENTS.md` + 3 loop docs (h-035). **Doctor #12(a–e)** (prose in `agents/nortropic-steward.md`, executed by an LLM agent from `workflows/nortropic-verify-suite.js`): parses `02-agenter.md` table; path-existence in `03-regelverk.md`; command refs in README/docs; `Senast verifierad` staleness on every `docs/*.md` (arkiv excluded); `00-borja-har.md` commit-date vs `docs/01-07`+README. **Konstitution §B line-parses `05-beslutslogg.md`** (`^RETRO-1-GENOMFÖRD`, `CHECKPOINT`). `docs/100-dagar/baseline-manifest-20260730.sha256` freezes SHA-256 of 12 doc files incl. arkiv. No CI (`.github/` absent). `.claude/` git-ignored; `.agents/skills/*` (6 tracked Codex role skills) point at AGENTS.md/07/03/regler.md/evidence contract/report schema. Dangling: `verify/bin/autonomous-loop-exit` (named in AGENTS.md, absent — autopilot Stops); off-main plan pair.

## 4. Classification — verkstadsgolvet (recommendations only)

| path | classification | evidence/reason | inbound refs/risk |
|---|---|---|---|
| `CLAUDE.md` | KEEP | Repo constitution; Tier 1 | hook, settings deny, 4 agent prompts, doctor, smoke, tests |
| `docs/nortropic-control-room-plan-v1.md` | KEEP | Frozen spec; NEVER_WRITABLE; test KÄLLA; read at runtime by v10 test | backlog `plan`+`planBaseSha`; 11+ tests |
| `docs/claude-operating-model-v1.md` | KEEP | Workflow contract; triple-guarded, test-asserted | doctor, tests, hook, settings |
| `docs/nortropic-control-room-codex-handoff.md` | KEEP | NEVER_WRITABLE entrypoint w/ pinned SHAs | settings deny ×2, scope.ts, backlog test |
| `docs/claude-loop-runbook.md` | KEEP | Active runbook; test-enforced supersession notice | publication-merge-commit test, authority-lane fixture |
| `docs/nortropic-factory-room-master-roadmap-v1.md` | KEEP | FROZEN requirements spec; live programme | backlog `.roadmap`; room-* tests |
| `docs/nortropic-factory-room-handoff-v1.md` | KEEP | Live entrypoint; 34-step EXACT_NEXT_ACTION | backlog `.handoff` |
| `docs/nortropic-factory-room-roadmap-erratum-01.md` | KEEP | Active erratum, wins on its subjects | 4 test files; backlog `.errata` |
| `docs/nortropic-factory-room-product-erratum-v2.md` | KEEP | Active erratum (P1–P34) | backlog, handoff, addendum-v3 |
| `docs/nortropic-factory-room-requirement-addendum-v3.md` | KEEP | Owner-authored; verbatim-preservation constraint | handoff byte-identity claim |
| `docs/nortropic-factory-room-lanes-clarification.md` | KEEP | Newest owner doc; required pre-read for UX slices | handoff; visual review §13 |
| `docs/reports/nortropic-factory-room-final-report-2026-08-15.md` | UNCERTAIN (copy-don't-move) | Historical, zero inbound code refs; errata freeze `docs/reports/**` in place | removal contradicts frozen errata prose |
| `VERKSTADSGOLVET-BYGGSPEC.md` | UNCERTAIN | Superseded by ÄGARBESLUT 1; frozen plan quotes its line 11 by number | line-number citation from NEVER_WRITABLE doc |
| `KUND-ONBOARDING-BYGGSPEC.md` | SAFE_TO_COPY_PENDING_OWNER_REVIEW | Invariants re-encoded in `README.md` + `lib/prompt-research.ts`; zero inbound refs | dangling `PROMPT-RESEARCH.md` ref noted |
| `README.md` | KEEP | Deploy/env runbook + normative §Invarianter | cited by plan/handoff |
| `backlog/README.md` | KEEP | Documents canonical backlog fields | cited by runbook |
| `db/LEADS-SETUP.md`, `db/n8n-leads-flow.md` | KEEP | Operational; LEADS-SETUP cited by frozen plan + handoff §VERIFY_BEFORE_CHANGE | frozen-doc references |
| `reference/nortropic-verkstadsgolvet.html` | KEEP | Cited by line number from frozen plan | README, BYGGSPEC, plan |
| `content/**` (14 loaded) | KEEP | Runtime product data | moving breaks six routes |
| `content/leads/LEADS-TEST-SMS-DEMO.md` | KEEP | Comment-referenced product copy | `lib/leads-sms.ts:4` |
| `.claude/**`, `scripts/claude-loop/owner-author/system-prompt.md` | KEEP | Executable authority; marker-checked at runtime | scope.ts, lanes.ts, doctor |

## 5. Classification — nortropic-system (recommendations only)

| path | classification | evidence/reason | inbound refs/risk |
|---|---|---|---|
| `CLAUDE.md` | KEEP | §A member; pointer-only by rule (§5 C3 "två sanningar") | denied_write, Seatbelt, autopilot |
| `AGENTS.md` | KEEP | Authority router; owner amendments v2–v4 | h-035 docs_impact; 6 role skills |
| `README.md` | KEEP | Entry map; doctor #12(c)/(d)/(e) scope | drift guard |
| `docs/00-borja-har.md` | KEEP | Rule 22; doctor #12(e) anchor — missing = deviation | h-007 docs_impact; policy tests |
| `docs/00-guide.md` | KEEP | Version-coupled operator manual; stamp regime | steward SYSTEM MAP |
| `docs/01-oversikt.md` | KEEP | Derived from frontmatter; #12(d)/(e) | version-coupled |
| `docs/02-agenter.md` | KEEP | Machine-read by doctor #12(a) | mechanical parse contract |
| `docs/03-regelverk.md` | KEEP | §A1; rule 4 KANON | denied_write; PRETASK_PATHS (Integritetsfel) |
| `docs/04-justeringskarta.md` | KEEP | Implementation-coupled tuning map | steward SYSTEM MAP (§A-protected) — HÖGRISK edit needed to relocate |
| `docs/05-beslutslogg.md` | KEEP | Line-parsed by konstitution §B3/§B5; append-only | docs_impact ×43; 5 frozen gates |
| `docs/06-scope.md` | KEEP | Cited in autobygg gate prompt | normative boundary |
| `docs/07-konstitution.md` | KEEP | Highest authority; §A8 self-protected; HÖGRISK-only | everything |
| `docs/loop/regler.md` | KEEP | Authority #3 | PRETASK_PATHS |
| `docs/loop/byggplan-v3.md` | KEEP | `authority.plan`; §3.1 = binding denied_write set | h-016 docs_impact |
| `docs/loop/implementation-v4.1.md` | KEEP | `authority.architecture`; binding where not overridden | spec reference |
| `docs/loop/drift.md` | KEEP | Ops manual + append-log | docs_impact ×13; 4 frozen gates |
| `docs/loop/granskningsrubrik.md` | KEEP | Active review rubric | byggplan-v3 §8 |
| `docs/loop/loop-review-2026-07-31.md` | SAFE_TO_COPY_PENDING_OWNER_REVIEW | Historical review of out-of-repo plan version; zero inbound refs | none found |
| `docs/loop/codex-autopilot-v2.md` | UNCERTAIN | Only partially superseded by v3 | owner must rule |
| `docs/loop/codex-autopilot-v3-full-roadmap.md` | KEEP | Autopilot Stop if absent from origin/main | cross-repo ref from vg backlog |
| `docs/loop/codex-autopilot-report.schema.json` | KEEP | Loaded/validated by h-031/h-032 gates + autopilot | most code-coupled doc |
| `docs/loop/codex-evidence-contract.md` | KEEP | AGENTS.md report mandate; 4 role skills | contract |
| `docs/loop/harness-substitution-contract-v1.md` | KEEP | Blob-SHA-pinned; canonical owner contract | 1 byte ⇒ autopilot halt |
| `docs/loop/harness-substitution-audit-2026-08-11.md` | KEEP | Blob-SHA-pinned despite research form | same |
| `docs/loop/owner-author-workflow-v1.md` | KEEP | h-035-exit literal-string assertions | frozen gate |
| `docs/loop/owner-h003-attestation-authority-v1.md` | KEEP | Autopilot Stop if absent | forbidden-SHA clause |
| `docs/loop/remaining-bootstrap-delegation-v1.md` | KEEP | h-035-exit reads text | docs_impact ×2 |
| off-main plan pair @ `0b3212c9` | KEEP | Blob-pinned live authority via `git show` | invisible to docs listing |
| `docs/loop/arkiv/5z-inventering-2026-08-07.md` | UNCERTAIN | Archive legend cited by active plan §5 C1 | plan citation |
| `docs/loop/arkiv/post-workspace/*` | UNCERTAIN | "Kravinput till skiva 6–7" — input to unbuilt slices | future-slice dependency |
| `docs/100-dagar/programregister.md` | KEEP | `authority.backlog`; "enda backloggen" | spec reference |
| `docs/100-dagar/baseline-manifest-20260730.sha256` | KEEP | Frozen trust/integrity artifact; tag used by 3 tests | audit artifact |
| `docs/arkiv/systemplan.md` | UNCERTAIN | Linked from beslutslogg header; manifest-hashed; SYSTEM MAP | append-only log link |
| `docs/arkiv/lokal-flytt.md` | UNCERTAIN | Historical; README + SYSTEM MAP + manifest | HÖGRISK edits needed |
| `docs/arkiv/hantverkare-profil-v13.md` | UNCERTAIN | Steward :83 relates to living profile library | §A-protected referencer |

## 6. Cross-repository duplication / overlap

1. Role-separation doctrine (WORKFLOW, not security boundary) stated authoritatively in both repos — candidate for one explanatory `references/` page; both originals stay normative. 2. Frozen-plan + errata + handoff pattern exists independently in both — pattern is knowledge; instances stay. 3. Hard cross-repo references that must never break: vg `backlog/nortropic-factory-room-master-v1.json:255,537` → ns `docs/loop/codex-autopilot-v3-full-roadmap.md`; vg plan pins ns backend plan @ `0b3212c9` (sha256 identity proof); roadmap pins `NORTROPIC_SYSTEM_MAIN=32b6e07…`; vg CLAUDE.md defers trust/promotion to ns. 4. Evidence-language conventions duplicated (No percentages, PROVEN/OVERIFIERAT). 5. Parallel autonomous-loop operating models (Codex autopilot vs Claude Factory) — explanation-level overlap only.

## 7. Migration risks (recorded; no migration authorized)

Blob-SHA pins (byte change halts autopilot); authority snapshot `Integritetsfel`; literal-string gates (h-035-exit; vg publication-merge-commit test); machine-parsed docs (§B tokens, doctor #12(a)/(e)); docs_impact commit-coupling; baseline manifest path+hash pins on `docs/arkiv/*`; vg verbatim/byte-identity constraints; NEVER_WRITABLE docs handleable only by owner hand outside lanes; line-number citations from frozen docs (BYGGSPEC line 11; reference HTML line 170); cross-repo backlog path; "två sanningar" ban ⇒ knowledge repo must hold pointers/distillations, never normative copies; deliberate preserved contradictions (final report `TERMINAL_REASON=B` vs handoff) must not be "fixed"; pre-existing dangling refs (`verify/bin/autonomous-loop-exit`, `PROMPT-RESEARCH.md`, post-workspace prompt files) are findings, not migration targets.

## 8. Candidate sets (recommendations, not owner decisions)

**SAFE_TO_COPY_PENDING_OWNER_REVIEW**: ns `docs/loop/loop-review-2026-07-31.md`; vg `KUND-ONBOARDING-BYGGSPEC.md`.
**REQUIRES_OWNER_DECISION**: ns `codex-autopilot-v2.md`, `docs/arkiv/*` (3), `docs/loop/arkiv/*` (3); vg final report, `VERKSTADSGOLVET-BYGGSPEC.md`.
**MUST_STAY_WITH_CODE**: everything else in both repos (see §4/§5).

**Incidental findings** (pre-existing): vg CLAUDE.md stale vs `scope.ts` (4 vs 10 protected patterns); vg `doctor.ts` doesn't require the codex handoff or any factory-room doc; showroom-contract test attributes an erratum-02 lock to erratum-01; ns konstitution stamp (2026-07-28) is a known open doctor #12(d) WARN.

---
INSPECTION_ONLY=YES
FILES_MODIFIED=NO
GIT_STATE_MODIFIED=NO
KNOWLEDGE_REPO_CREATED=NO
MIGRATION_AUTHORIZED=NO
---
