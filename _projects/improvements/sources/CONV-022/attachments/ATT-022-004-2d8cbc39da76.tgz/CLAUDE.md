# nortropic-knowledge

```
NORTROPIC_KNOWLEDGE_IS_EXECUTION_AUTHORITY=NO
```

This repository is institutional knowledge: context, never trust or execution authority. The source repositories (`Nortropic/nortropic-system`, `Nortropic/verkstadsgolvet`) remain canonical for everything normative.

Rules live in exactly two places — do not restate them here:

- `AGENTS.md` — how agents must work in this repository.
- `GOVERNANCE.md` — boundaries, metadata convention, copy and provenance rules.
