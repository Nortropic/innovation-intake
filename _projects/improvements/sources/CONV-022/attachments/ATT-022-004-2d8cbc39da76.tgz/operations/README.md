# operations/

General how-we-operate knowledge, and retired runbooks after owner classification.

**Does not belong here:** active runbooks (for example nortropic-system `docs/loop/drift.md` or verkstadsgolvet `docs/claude-loop-runbook.md`). Active operational documentation stays with the code it operates.
