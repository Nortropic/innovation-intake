# learnings/

Lessons and reviews with no inbound coupling from any source repository.

**Does not belong here:** anything cited by an active plan, spec, gate, or test in a source repository — inbound coupling means the document stays with the code that references it.
