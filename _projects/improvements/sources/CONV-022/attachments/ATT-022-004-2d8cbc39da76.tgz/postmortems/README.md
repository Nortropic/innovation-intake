# postmortems/

Incident narratives written fresh for this repository.

**Does not belong here:** rewrites of frozen historical notes that live in source repositories — history there is preserved in place, not rewritten. A postmortem here may reference such notes but never replaces them.
