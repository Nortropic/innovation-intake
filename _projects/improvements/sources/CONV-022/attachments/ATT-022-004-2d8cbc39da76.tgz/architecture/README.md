# architecture/

Fresh conceptual distillations of how the Nortropic systems work — for example the loop roles, the trappan model, the ring model, the control-room concept, and the frozen-plan + errata + handoff pattern — written in this repository's own words.

**Does not belong here:** the authoritative originals, or anything a gate, verifier, test, or agent in a source repository reads. Those stay in their source repositories; point to them from `references/`.
