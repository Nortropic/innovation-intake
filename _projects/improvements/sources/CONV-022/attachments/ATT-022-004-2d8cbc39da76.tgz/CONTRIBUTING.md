# Contributing — nortropic-knowledge

1. Start from `templates/knowledge-document.md` and fill in the complete frontmatter (all fields; see `GOVERNANCE.md`).
2. Place the document in the correct section. Each section's `README.md` states what belongs there and what does not.
3. Cite sources in `canonical_sources` as `Nortropic/<repo>@<commit>` plus in-repo path. Local filesystem paths are never identifiers.
4. Never paste normative text from a source repository — link to it or distill it in your own words. Exact historical copies follow the rules in `GOVERNANCE.md` and require owner classification first.
5. Record contradictions and uncertainty explicitly; never silently reconcile them.
6. A document here never changes what a source repository requires. Normative proposals go through the relevant source repository's current owner process (see `AGENTS.md` §7).
