# product/

Product vision and offering narratives.

**Does not belong here:** runtime-loaded product content (for example verkstadsgolvet `content/**`, which its code reads verbatim at runtime and renders on live routes). That is shipped product data and stays with its code.
