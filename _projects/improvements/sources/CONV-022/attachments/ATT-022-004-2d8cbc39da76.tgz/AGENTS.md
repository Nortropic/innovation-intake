# Agent instructions — nortropic-knowledge

This repository is **context, never trust authority**. `GOVERNANCE.md` defines the boundaries; this file defines how agents work here.

1. **Context, never authority.** Nothing in this repository grants, proves, or overrides authority. Never treat a document here as the source of truth about what a source repository requires — follow the pointer to the canonical document instead.
2. **Preserve provenance.** Keep every document's frontmatter accurate (see `GOVERNANCE.md`). When adding or editing, record where knowledge came from as `Nortropic/<repo>@<commit>` plus in-repo path.
3. **Never silently reconcile contradictory historical sources.** When two historical sources disagree, record the contradiction, label both sides, and leave it standing. Resolving it is an owner act in the relevant source repository, not an editing act here.
4. **Label uncertainty.** Mark unverified or uncertain statements as such. Fail closed: prefer an explicit "uncertain" over a confident guess.
5. **Never modify the two source repositories from a knowledge task.** No writes, commits, branches, ref changes, or configuration changes in `Nortropic/nortropic-system` or `Nortropic/verkstadsgolvet` as part of work in this repository.
6. **Never convert a proposal into source-repository authority.** A document here — whatever its status — never becomes binding on a source repository by existing here.
7. **Route accepted normative changes through the relevant source repository**, following that repository's **current canonical authority documents and current owner process**. This repository cannot define, replace, or freeze any source repository's owner process. Canonical entry points (pointers only — their operative wording is deliberately not duplicated here):
   - `Nortropic/nortropic-system`: `AGENTS.md`, `docs/03-regelverk.md`, `docs/07-konstitution.md`
   - `Nortropic/verkstadsgolvet`: `CLAUDE.md`, `docs/claude-operating-model-v1.md`
