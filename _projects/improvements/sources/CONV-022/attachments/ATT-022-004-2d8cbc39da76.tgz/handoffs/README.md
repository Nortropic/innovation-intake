# handoffs/

**Retired** handoffs only, entered after owner classification.

**Does not belong here:** any current handoff. Both source repositories' handoffs are live session entrypoints and remain with their code until the owner classifies them as retired.
