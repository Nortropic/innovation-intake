# nortropic-knowledge

Institutional knowledge system for Nortropic: distillations, research, learnings, historical snapshots, and pointer indexes.

This repository is **not** execution authority and **not** a migration of existing authority.

## Governing boundary

```
NORTROPIC_KNOWLEDGE_IS_EXECUTION_AUTHORITY=NO
SOURCE_REPOSITORY_AUTHORITY_WINS=YES
RUNTIME_DEPENDENCY_ON_KNOWLEDGE_REPO=FORBIDDEN
VERIFICATION_DEPENDENCY_ON_KNOWLEDGE_REPO=FORBIDDEN
NORMATIVE_SECOND_SOURCE_OF_TRUTH=FORBIDDEN
SOURCE_REPOSITORIES_MODIFIED=NO
```

The source repositories remain canonical for everything normative. Nothing in this repository can define, replace, freeze, or override a source repository, its documents, or its owner process.

## Source repositories (inspected snapshot)

```
INSPECTED_SNAPSHOT_AS_OF=2026-08-15
```

| Source | Inspected commit | Inspected state |
|---|---|---|
| `Nortropic/nortropic-system` | `e56edc08e5f069f16b5bdb853302a0f39c1f7075` | detached HEAD equal to origin/main |
| `Nortropic/verkstadsgolvet` | `330457cfa56646d5f56b7746c0e0064009505eb5` | origin/main (the local `main` checkout was stale and was not used as an authority snapshot) |

These identities are a dated inspection snapshot — they are **not** a claim that the source repositories are currently at these commits. Canonical identity is always `Nortropic/<repo>@<commit>` plus in-repo path. Local filesystem paths (for example `~/nortropic/...`) are convenience paths only and are never canonical identifiers.

## Sections

- `architecture/` — fresh conceptual distillations; never the authoritative originals.
- `decisions/` — narrative context around owner decisions after retirement from an authority chain.
- `rfcs/` — explorations before they become owner decisions.
- `research/` — original research and analysis.
- `product/` — product vision and offering narratives.
- `operations/` — general operating knowledge; retired runbooks after owner classification.
- `learnings/` — lessons and reviews with no inbound coupling.
- `postmortems/` — incident narratives written fresh.
- `handoffs/` — retired handoffs only, after owner classification.
- `references/` — pointer indexes to canonical documents in their home repositories.
- `reports/` — dated, non-authoritative snapshots.
- `archive/` — owner-approved historical copies with full provenance.
- `templates/` — document templates.

Each section's `README.md` states its exact purpose and what does not belong there.

## Rules

Rules live in exactly two places: `GOVERNANCE.md` (boundaries, metadata convention, copy and provenance rules) and `AGENTS.md` (how agents work here). `CLAUDE.md` is a pointer only.
