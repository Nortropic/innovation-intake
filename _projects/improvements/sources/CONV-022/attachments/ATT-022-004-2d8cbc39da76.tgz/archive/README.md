# archive/

Owner-approved exact historical copies, each with full provenance recorded inside the document: source repository, original path, source commit, and source blob identity (`git rev-parse <commit>:<path>`).

**Does not belong here:** anything frozen, protected, machine-read, path-referenced, or byte-pinned in a source repository that the owner has not explicitly released for copying. When in doubt, it does not enter this directory.
