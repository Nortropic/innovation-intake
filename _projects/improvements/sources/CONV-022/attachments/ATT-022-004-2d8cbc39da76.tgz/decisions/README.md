# decisions/

Narrative context around owner decisions **after** they have been retired from an authority chain in a source repository.

**Does not belong here:** the decision logs of the source repositories (for example `docs/05-beslutslogg.md` content), any live owner decision, or anything still binding in a source repository.
