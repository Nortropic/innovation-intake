# rfcs/

Explorations and proposals before they become owner decisions. Documents here carry status `draft` or `proposed`.

**Does not belong here:** anything presented as already decided. A proposal here never becomes source-repository authority by existing here — acceptance happens through the relevant source repository's owner process.
