# references/

Pointer indexes to canonical documents in their home repositories. Each entry records: source repository, source path, exact inspected source commit, document role, and authority category — never the contents.

**Does not belong here:** copies of the documents being pointed to, or any claim that this repository can override a source repository. The source repository always remains canonical.
