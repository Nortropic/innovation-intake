---
status: accepted-informational
authority: none
provenance: index
created: 2026-08-15
last_reviewed: 2026-08-15
canonical_sources:
  - Nortropic/nortropic-system@e56edc08e5f069f16b5bdb853302a0f39c1f7075
supersedes: []
superseded_by: []
---

# Reference index — Nortropic/nortropic-system

```
INSPECTED_SNAPSHOT_AS_OF=2026-08-15
```

Source repository: `Nortropic/nortropic-system`. Inspected commit: `e56edc08e5f069f16b5bdb853302a0f39c1f7075` (detached HEAD equal to origin/main at inspection time). This is a dated snapshot, not a claim about the repository's current state.

**The source repository remains canonical. This index describes document roles; it copies no normative contents and can never override the source repository.** Entries record the inspected commit per row; two entries carry an entry-specific off-main commit. Paths are in-repo paths; local filesystem paths are never identifiers.

## Authority

| Source path | Inspected commit | Role |
|---|---|---|
| `docs/07-konstitution.md` | `e56edc08…` | Highest normative authority ("grundlagen"); changed only by a human |
| `docs/03-regelverk.md` | `e56edc08…` | The hard rules and invariants; canonical home of the authority order |
| `docs/loop/regler.md` | `e56edc08…` | Binding build rules for the control plane, subordinate to the two above |
| `AGENTS.md` | `e56edc08…` | Authority router for agents; owner amendments are recorded here |
| `CLAUDE.md` | `e56edc08…` | Deliberately pointer-only entry file; member of the protected path set |
| `docs/loop/byggplan-v3.md` | `e56edc08…` | Active build plan; defines the protected path set the machinery enforces |
| `docs/loop/implementation-v4.1.md` | `e56edc08…` | Architecture authority where not overridden by the build plan |
| `docs/loop/harness-substitution-contract-v1.md` | `e56edc08…` | Owner contract for implementation shape; blob-pinned by the autopilot |
| `docs/loop/harness-substitution-audit-2026-08-11.md` | `e56edc08…` | Audit behind that contract; also blob-pinned by the autopilot |
| `docs/loop/owner-author-workflow-v1.md` | `e56edc08…` | Frozen effect contract; literal strings asserted by a frozen gate |
| `docs/loop/owner-h003-attestation-authority-v1.md` | `e56edc08…` | Task-scoped owner decision; required on origin/main by the autopilot |
| `docs/loop/remaining-bootstrap-delegation-v1.md` | `e56edc08…` | Owner delegation; read by a frozen gate |
| `docs/loop/codex-autopilot-v3-full-roadmap.md` | `e56edc08…` | Owner operating model for full-roadmap autonomy; required on origin/main |
| `docs/loop/autonomous-loop-plan-v1.md` | `0b3212c991d4227c8df2656465ae2c0252dda39e` | Frozen roadmap plan; exists only at this off-main commit and is read via `git show` by design |
| `docs/loop/autonomous-loop-codex-handoff.md` | `0b3212c991d4227c8df2656465ae2c0252dda39e` | Frozen handoff paired with that plan; same off-main commit |

## Code-coupled documentation

| Source path | Inspected commit | Role |
|---|---|---|
| `docs/05-beslutslogg.md` | `e56edc08…` | Append-only decision log; specific line-start tokens in it are machine-parsed by the constitution's gates |
| `docs/02-agenter.md` | `e56edc08…` | Agent table whose rows are machine-read by a doctor check |
| `docs/00-borja-har.md` | `e56edc08…` | Simple documentation layer; its commit date anchors a mechanical drift guard |
| `docs/loop/codex-autopilot-report.schema.json` | `e56edc08…` | JSON Schema loaded and validated against by frozen gates and the autopilot |
| `docs/loop/drift.md` | `e56edc08…` | Operations log required in-commit by many task definitions and asserted by frozen gates |
| `docs/loop/codex-evidence-contract.md` | `e56edc08…` | Report-format contract that agent reports must follow |
| `docs/100-dagar/programregister.md` | `e56edc08…` | The declared backlog of the 100-day program |
| `docs/100-dagar/baseline-manifest-20260730.sha256` | `e56edc08…` | Frozen integrity manifest of the program baseline |

## Operational documentation

| Source path | Inspected commit | Role |
|---|---|---|
| `docs/00-guide.md` | `e56edc08…` | Operator manual; self-declares deference to system files |
| `docs/01-oversikt.md` | `e56edc08…` | Pipeline/node overview derived from agent definitions |
| `docs/04-justeringskarta.md` | `e56edc08…` | Living map of tunable design choices with exact file pointers |
| `docs/06-scope.md` | `e56edc08…` | Ring-model business/product boundary; cited in a workflow gate prompt |
| `README.md` | `e56edc08…` | Repository entry map; inside the doctor's drift-guard scope |
| `docs/loop/granskningsrubrik.md` | `e56edc08…` | Frozen review rubric for control-plane pull requests |

## Historical context

| Source path | Inspected commit | Role |
|---|---|---|
| `docs/arkiv/systemplan.md` | `e56edc08…` | Frozen pre-git design history; linked from the decision log |
| `docs/arkiv/lokal-flytt.md` | `e56edc08…` | Completed run-once operator checklist |
| `docs/arkiv/hantverkare-profil-v13.md` | `e56edc08…` | Frozen v13 profile snapshot, related to a living profile library |
| `docs/loop/arkiv/5z-inventering-2026-08-07.md` | `e56edc08…` | Archived evidence inventory ("arkivlegend") behind the plan restart |
| `docs/loop/arkiv/post-workspace/README.md` | `e56edc08…` | Archived requirement input to future slices; not installed |
| `docs/loop/arkiv/post-workspace/POST_WORKSPACE_ARCHITECTURE.md` | `e56edc08…` | Companion architecture note to the above |
| `docs/loop/loop-review-2026-07-31.md` | `e56edc08…` | Historical external review that motivated a later plan version |
| `docs/loop/codex-autopilot-v2.md` | `e56edc08…` | Earlier operating model; **uncertain** — only partially superseded by v3 (uncertainty labeled, not resolved) |

---

The source repository remains canonical. This index can never override it.
