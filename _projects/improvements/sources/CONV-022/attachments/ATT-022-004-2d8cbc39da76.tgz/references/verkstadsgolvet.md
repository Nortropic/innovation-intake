---
status: accepted-informational
authority: none
provenance: index
created: 2026-08-15
last_reviewed: 2026-08-15
canonical_sources:
  - Nortropic/verkstadsgolvet@330457cfa56646d5f56b7746c0e0064009505eb5
supersedes: []
superseded_by: []
---

# Reference index — Nortropic/verkstadsgolvet

```
INSPECTED_SNAPSHOT_AS_OF=2026-08-15
```

Source repository: `Nortropic/verkstadsgolvet`. Inspected commit: `330457cfa56646d5f56b7746c0e0064009505eb5` (**origin/main** at inspection time). The local `main` checkout was stale (57 commits behind) at inspection and **was not used as an authority snapshot**. This is a dated snapshot, not a claim about the repository's current state.

**The source repository remains canonical. This index describes document roles; it copies no normative contents and can never override the source repository.** Paths are in-repo paths at the inspected commit; local filesystem paths are never identifiers.

## Authority

| Source path | Inspected commit | Role |
|---|---|---|
| `CLAUDE.md` | `330457cf…` | Repository constitution for Claude Factory work; mechanically protected |
| `docs/nortropic-control-room-plan-v1.md` | `330457cf…` | Frozen control-room plan; never writable by any lane; defers to nortropic-system for trust matters |
| `docs/claude-operating-model-v1.md` | `330457cf…` | Owner workflow contract for Claude-powered development; mechanically protected |
| `docs/nortropic-control-room-codex-handoff.md` | `330457cf…` | Owner-authored entrypoint to the plan; never writable by any lane |
| `docs/nortropic-factory-room-master-roadmap-v1.md` | `330457cf…` | Frozen requirements roadmap for the Factory Room programme |
| `docs/nortropic-factory-room-roadmap-erratum-01.md` | `330457cf…` | Erratum that prevails on its named subjects without editing the frozen roadmap |
| `docs/nortropic-factory-room-product-erratum-v2.md` | `330457cf…` | Second erratum; extends the first; prevails on its named subjects |
| `docs/nortropic-factory-room-requirement-addendum-v3.md` | `330457cf…` | Owner addendum recorded verbatim; byte-identity preservation constraint |
| `docs/nortropic-factory-room-lanes-clarification.md` | `330457cf…` | Owner clarification recorded verbatim; required pre-read for Factory Room UX work |
| `docs/nortropic-factory-room-handoff-v1.md` | `330457cf…` | Live session entrypoint for the programme; updated only via a dedicated status task |

## Code-coupled documentation

| Source path | Inspected commit | Role |
|---|---|---|
| `backlog/control-room-v1.json` | `330457cf…` | Canonical backlog; references the plan by path and pinned base SHA |
| `backlog/nortropic-factory-room-master-v1.json` | `330457cf…` | Programme backlog referencing roadmap, handoff, and all errata by path |
| `backlog/README.md` | `330457cf…` | Field documentation for the canonical backlog |
| `.claude/agents/*.md` (4 files) | `330457cf…` | Agent role definitions; cite the constitution and the frozen plan |
| `.claude/settings.json`, `.claude/hooks/pre-tool-guard.mjs` | `330457cf…` | Mechanical protection of the authority paths |
| `scripts/claude-loop/owner-author/system-prompt.md` | `330457cf…` | Owner-author lane prompt; marker-checked at runtime |
| `content/**` (14 runtime-loaded files) | `330457cf…` | Shipped product data read verbatim at runtime and rendered on live routes |

## Operational documentation

| Source path | Inspected commit | Role |
|---|---|---|
| `docs/claude-loop-runbook.md` | `330457cf…` | Active runbook for the Claude Factory loop; carries a test-enforced supersession mechanism |
| `README.md` | `330457cf…` | Deploy/env runbook with the repository's invariants |
| `db/LEADS-SETUP.md` | `330457cf…` | Leads/database setup runbook; cited by the frozen plan and handoff |
| `db/n8n-leads-flow.md` | `330457cf…` | Workflow import guide for the leads flow |
| `reference/nortropic-verkstadsgolvet.html` | `330457cf…` | Visual prototype; cited by line number from the frozen plan |

## Historical context

| Source path | Inspected commit | Role |
|---|---|---|
| `docs/reports/nortropic-factory-room-final-report-2026-08-15.md` | `330457cf…` | Final autonomous build report; frozen in place by the errata ("historical reports are not edited"); its terminal conclusion is superseded by the handoff — a contradiction preserved by design, labeled here, not reconciled |
| `VERKSTADSGOLVET-BYGGSPEC.md` | `330457cf…` | Original build spec; partially superseded by owner decision recorded in the plan; still quoted by line number from the frozen plan |
| `KUND-ONBOARDING-BYGGSPEC.md` | `330457cf…` | Onboarding build spec; its invariants are re-encoded in the README and code |

---

The source repository remains canonical. This index can never override it.
