# Governance — nortropic-knowledge

## Governing boundary

```
NORTROPIC_KNOWLEDGE_IS_EXECUTION_AUTHORITY=NO
SOURCE_REPOSITORY_AUTHORITY_WINS=YES
RUNTIME_DEPENDENCY_ON_KNOWLEDGE_REPO=FORBIDDEN
VERIFICATION_DEPENDENCY_ON_KNOWLEDGE_REPO=FORBIDDEN
NORMATIVE_SECOND_SOURCE_OF_TRUTH=FORBIDDEN
SOURCE_REPOSITORIES_MODIFIED=NO
```

No process in any source repository may depend on this repository at runtime or at verification time. This repository must never become a submodule or runtime dependency of either source repository.

## Metadata convention

Every substantive knowledge document carries valid YAML frontmatter with both opening and closing `---` delimiters:

```yaml
---
status: draft | research | proposed | accepted-informational | superseded | historical
authority: none | informational
provenance: original | derived | index | historical-copy
created: YYYY-MM-DD
last_reviewed: YYYY-MM-DD
canonical_sources: []
supersedes: []
superseded_by: []
---
```

- `canonical_sources` entries use the form `Nortropic/<repo>@<commit>` (optionally suffixed with an in-repo path).
- No `authority` value grants execution authority. **`accepted-informational` does not mean executable authority** — it means the owner accepted the document as good information, nothing more.

## Copy and provenance rules

- **Reference or distill, don't copy.** Authority-linked documents are normally referenced (in `references/`) or distilled into fresh text — not copied.
- **Exact historical copies** (`provenance: historical-copy`) require, recorded inside the document: source repository, original path, source commit, and **source blob identity** (`git rev-parse <commit>:<path>`). They also require prior owner classification.
- **Current handoffs remain with their code repositories.** Retired handoffs may enter `handoffs/` only after owner classification.
- **No secrets.** No secrets, credentials, private keys, tokens, or environment files belong in this repository.

## Owner process

Normative changes are routed through the relevant source repository, under that repository's current canonical authority documents and current owner process. This repository cannot define, replace, or freeze that process. It points to canonical source paths (see `AGENTS.md` and `references/`) and never duplicates their operative wording.
